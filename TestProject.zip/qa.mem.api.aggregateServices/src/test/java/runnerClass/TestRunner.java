package runnerClass;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.fasterxml.jackson.databind.ObjectMapper;
import utility.APIConstants;
import utility.Util;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import io.restassured.RestAssured;


@CucumberOptions(
        features = {"./Scenarios/"},
        glue = {"stepDefinitions"},
        tags = "@regression",
        plugin = { "pretty", "html:target/cucumber-reports.html", "json:target/cucumber.json" },
        monochrome = true,
        dryRun = false
        
)

public class TestRunner extends AbstractTestNGCucumberTests{
	public static PropertiesConfiguration config = null;
	public static PropertiesConfiguration testdata = null;
	public static PropertiesConfiguration application = null;
	public static PropertiesConfiguration dbconnection = null;
	public static ExtentHtmlReporter extentReport = null;
	public static ExtentReports extent = null;
	public static ExtentTest test = null;
	public static Map<String, String> headers = null;
	public static ObjectMapper mapper = null;
	public static String env = null;
	
	
	@BeforeMethod(alwaysRun = true)
	public void initProperties() throws Exception {
		
		config = new PropertiesConfiguration(APIConstants.CONFIG_FILE_PATH);
		testdata = new PropertiesConfiguration(APIConstants.TESTDATA_FILE_PATH);
		application = new PropertiesConfiguration(APIConstants.APPLICATION_FILE_PATH);
		dbconnection=new PropertiesConfiguration(APIConstants.DBCONNECTION_FILE_PATH);
		RestAssured.useRelaxedHTTPSValidation();
		headers = new HashedMap();
		mapper = new ObjectMapper();
		headers.put("Authorization", Util.getAccessToken());
		
	}

	@BeforeSuite(alwaysRun = true)
	public void initReportProperties() {
		env = System.getenv("env");
		if (env == null) {
			env = "qa";
		}
		extent = new ExtentReports();
		String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		extentReport = new ExtentHtmlReporter("./testReports/EP_MicroServices_Automation.html");
		extentReport.config().setReportName("Managing-Expenses-Microservices Test Report");
		extent.attachReporter(extentReport);

	}

	@AfterMethod(alwaysRun = true)
	public void getResult(ITestResult result) {

		if (result.getStatus() == ITestResult.FAILURE) {
			test.fail(MarkupHelper.createLabel(result.getName() + "TestCase failed", ExtentColor.RED));
			test.fail(result.getThrowable());
		} else if (result.getStatus() == ITestResult.SUCCESS) {
			test.pass(MarkupHelper.createLabel(result.getName() + "TestCase Passed", ExtentColor.GREEN));
		} else if (result.getStatus() == ITestResult.SKIP) {

			test.skip(MarkupHelper.createLabel(result.getName() + "TestCase Skipped", ExtentColor.YELLOW));
			test.skip(result.getThrowable());
		}

	}

	@AfterSuite(alwaysRun = true)
	public void tearDown() throws Exception {
		extent.flush();
	}

}
