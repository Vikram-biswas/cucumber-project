package utility;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import com.aventstack.extentreports.Status;
import com.fasterxml.jackson.databind.JsonNode;

import io.restassured.response.Response;
import runnerClass.TestRunner;
import stepDefinitions.StepDefinition;

public class AggregateServiceHelper extends TestRunner {
	public static String buildURI(String endpoint) {
		String requestURI = null;
		if (StepDefinition.env.equalsIgnoreCase("qa")) {
			String baseURI = config.getString("qaApigeeURI")/* + config.getString("version") */;
			requestURI = baseURI + endpoint;
		} else {
			String baseURI = config.getString("devApigeeURI")/* + config.getString("version") */;
			requestURI = baseURI + endpoint;
		}
		return requestURI;
	}

	public static String buildURISwagger(String endpoint) {
		String requestURI = null;
		if (StepDefinition.env.equalsIgnoreCase("qa")) {
			String baseURI = config.getString("qaSwaggerURI");
			requestURI = baseURI + endpoint;
		} else {
			String baseURI = config.getString("devSwaggerURI");
			requestURI = baseURI + endpoint;
		}
		return requestURI;
	}

	/*
	 * This method is used to get all the records
	 */
	public static String getrecords() throws Exception {
		Response response = Util.get(StepDefinition.url);
		JsonNode jsonResponse = Util.assertStatusCode(response, StatusCode.MESSAGE_200);
		String total_count = jsonResponse.get("total_count").asText();
		return total_count;
	}

	/*
	 * This method is used to create entries using POST requests with provided
	 * payload
	 */
	@SuppressWarnings("static-access")
	public static JsonNode createNewRecord(JsonNode payload, StatusCode statusCode) throws Exception {
		Response response = Util.post(StepDefinition.url, payload);
		JsonNode jsonResponse = Util.assertStatusCode(response, statusCode);
		return jsonResponse;
	}

	/*
	 * This method is used to get values based on the paramvalue
	 */
	public static JsonNode getResponseParam(String pathParam, String paramvalue) throws Exception {
		test.log(Status.DEBUG, "Fetched Parameter Value = " + paramvalue);
		Response response = Util.get(StepDefinition.url, pathParam, paramvalue);
		JsonNode getValueResponse = Util.assertStatusCode(response, StatusCode.MESSAGE_200);
		test.log(Status.DEBUG, "Fetched get response as = " + paramvalue);
		return getValueResponse;
	}

	public static JsonNode getResponse() throws Exception {
		Response response = Util.get(StepDefinition.url);
		JsonNode getValueResponse = Util.assertStatusCode(response, StatusCode.MESSAGE_200);
		return getValueResponse;
	}

	public static JsonNode getResponseParams(String[] pathParams, String[] paramvalues) throws Exception {
		test.log(Status.DEBUG, "Fetched Parameter Value = " + paramvalues);
		Response response = Util.get(StepDefinition.url, pathParams[0], paramvalues[0], pathParams[1], paramvalues[1]);
		JsonNode getValueResponse = Util.assertStatusCode(response, StatusCode.MESSAGE_200);
		return getValueResponse;
	}

	public static JsonNode getResponseParams1(String[] pathParams, String[] paramvalues) throws Exception {
		test.log(Status.DEBUG, "Fetched Parameter Value = " + paramvalues);
		Response response = Util.get(StepDefinition.url, pathParams[0], paramvalues[0], pathParams[1], paramvalues[1],
				pathParams[2], paramvalues[2]);
		JsonNode getValueResponse = Util.assertStatusCode(response, StatusCode.MESSAGE_200);
		return getValueResponse;
	}

	public static String getResponseCount() throws Exception {
		Response response = Util.get(StepDefinition.url);
		JsonNode getResponse = Util.assertStatusCode(response, StatusCode.MESSAGE_200);
		String total_count = getResponse.get("total_count").asText();
		test.log(Status.DEBUG, "Total record count is " + total_count);
		return total_count;
	}

	/*
	 * This method is used to validate GET response
	 */
	public static void validateGetResponse(JsonNode getValueResponse, String actual, String expected) throws Exception {
		test.log(Status.DEBUG, "Validating " + actual);
		test.log(Status.DEBUG, "Validating " + expected);
		boolean bol = getValueResponse.isArray();
		if (bol == true) {
			assertEquals(getValueResponse.get(0).get(actual).asText(), Util.getProperty(expected),
					"The" + actual + "did not match");
		} else {
			assertEquals(getValueResponse.get(actual).asText(), Util.getProperty(expected),
					"The" + actual + "did not match");
		}
	}

	/*
	 * This method is used to validate GET response
	 */
	public static void validatefieldResponse(JsonNode getValueResponse, String actual, String expected)
			throws Exception {
		test.log(Status.DEBUG, "Validating " + expected);
		boolean bol = getValueResponse.isArray();
		if (bol == true) {
			for (int i = 0; i < getValueResponse.size(); i++) {
				String expt = getValueResponse.get(i).get(actual).asText();
				if (expt.equals(expected)) {
					assertEquals(getValueResponse.get(i).get(actual).asText(), expected,
							"The" + actual + "did not match");
				}
			}
		} else {
			assertEquals(getValueResponse.get(actual).asText(), expected, "The" + actual + "did not match");
		}
	}

	/*
	 * This method will modify existing payload object response
	 */
	public static JsonNode getmodifiedPayloadResponse(JsonNode modifyPayload, String pathaParam, String pathParamValue)
			throws Exception {
		Response response = Util.put(StepDefinition.url, modifyPayload, pathaParam, pathParamValue);
		JsonNode jsonResponse = Util.assertStatusCode(response, StatusCode.MESSAGE_200);
		return jsonResponse;
	}

	public static JsonNode setPayload() throws IOException {

		Path path;
		JsonNode jsonFile = null;
		if (StepDefinition.payloadPath.equals("ppBankAccountReports")) {
			path = Paths.get(APIConstants.ppBankAccountReports);
			byte[] data = Files.readAllBytes(Paths.get(APIConstants.ppBankAccountReports));
			jsonFile = mapper.readTree(data);
		}
		test.log(Status.DEBUG, "Payload json file" + jsonFile);
		return jsonFile;
	}

	public static Response getResponseInvalidURLForNegative() throws Exception {

		Response response = Util.get(StepDefinition.url);
		return response;
	}

	public static Response getAllResponse() throws Exception {
		Response response = Util.get(StepDefinition.url);
		return response;
	}

	public static Response getResponseForNegative(String pathParam, String paramvalue) throws Exception {
		Response response;
		if (!pathParam.equalsIgnoreCase("null")) {
			test.log(Status.DEBUG, "Fetched Parameter Value = " + paramvalue);
			response = Util.get(StepDefinition.url, pathParam, paramvalue);
		} else {
			response = Util.get(StepDefinition.url);
		}
		return response;
	}

	public static void compareProjectGlTransactionApprovalsResponseWithserviceDB(JsonNode response) throws Exception {
		test.log(Status.INFO, "=========== Getting externalid from ServiceDB ==========");
		String query = null;
		query = dbconnection.getString("getProjectBatchesbyexternalid").replace("columnName", "external_id");
		String value = DbUtil.getPostgresDBQueryValue(query.replace("value", response.get("external_id").asText()));

	}

}
