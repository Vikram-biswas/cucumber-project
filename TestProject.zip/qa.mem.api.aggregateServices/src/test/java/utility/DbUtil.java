package utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.aventstack.extentreports.ExtentTest;

import runnerClass.TestRunner;

public class DbUtil extends TestRunner{
	public static ExtentTest test = null;

	public static Connection connectToDB(String host, String port, String db, String userName, String pswd)
			throws SQLException, ClassNotFoundException {
		Connection connection = DriverManager.getConnection("jdbc:postgresql://" + host + ":" + port + "/" + db,
				userName, pswd);
		Class.forName("org.postgresql.Driver");
		return connection;
	}

	public static Connection connectToSQLServer(String serverName, String port, String dbName, String userName,
			String pswd) throws Exception {
		String connectionUrl = "jdbc:sqlserver://" + serverName + ":" + port + ";" + "databaseName=" + dbName + ";user="
				+ userName + ";password=" + pswd;
		Connection connection = DriverManager.getConnection(connectionUrl);
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		return connection;
	}

	public static String getPostgresDBQueryValue(String sqlQuery) {
		Connection con;
		String responseFetchedValue = null;
		try {
			con = connectToDB(dbconnection.getString(env + "AggregateHost"), dbconnection.getString(env + "AggregatePort"),
					dbconnection.getString(env + "AggregateDatabase"), dbconnection.getString(env + "AggregateUsername"),
					dbconnection.getString(env + "AggregatePassword"));
			Statement stm = con.createStatement();
//		test.log(Status.DEBUG, "Query to fetch is" + sqlQuery);
			ResultSet rs = stm.executeQuery(sqlQuery);
			while (rs.next()) {
				responseFetchedValue = rs.getString(1);
			}
			rs.close();
			stm.close();
			con.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return responseFetchedValue;
	}

	public static String getSQLQueryValue(String sqlQuery) throws Exception {
		Connection con;
		String responseFetchedValue = null;
		try {
			con = connectToSQLServer(dbconnection.getString("sqlServerName"), dbconnection.getString("sqlPort"),
					dbconnection.getString("sqlDatabase"), dbconnection.getString("sqlUserName"),
					dbconnection.getString("sqlPassword"));
			Statement stm = con.createStatement();
//		test.log(Status.DEBUG, "Query to fetch is" + sqlQuery);
			ResultSet rs = stm.executeQuery(sqlQuery);
			while (rs.next()) {
				responseFetchedValue = rs.getString(1);
			}
			rs.close();
			stm.close();
			con.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return responseFetchedValue;
	}
	public static void insertDeleteRecord(String query) {
		Connection con;
		try {
			con = connectToDB(dbconnection.getString(env + "AggregateHost"), dbconnection.getString(env + "AggregatePort"),
					dbconnection.getString(env + "AggregateDatabase"), dbconnection.getString(env + "AggregateUsername"),
					dbconnection.getString(env + "AggregatePassword"));
			Statement stm = con.createStatement();
			stm.executeUpdate(query);
			stm.close();
			con.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void palsinsertDeleteRecord(String query) {
		Connection con;
		try {
			con = connectToDB(dbconnection.getString(env + "PalsHost"), dbconnection.getString(env + "PalsPort"),
					dbconnection.getString(env + "PalsDatabase"), dbconnection.getString(env + "PalsUsername"),
					dbconnection.getString(env + "PalsPassword"));
			Statement stm = con.createStatement();
			stm.executeUpdate(query);
			stm.close();
			con.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static boolean ifRecordExistpals(String query) {
		boolean flag = false;
		Connection con;
		try {
			con = connectToDB(dbconnection.getString(env + "PalsHost"), dbconnection.getString(env + "PalsPort"),
					dbconnection.getString(env + "PalsDatabase"), dbconnection.getString(env + "PalsUsername"),
					dbconnection.getString(env + "PalsPassword"));
			Statement stm = con.createStatement();
			ResultSet result = stm.executeQuery(query);
			if(result.next()==true) {
				flag=true;
			}			
			stm.close();
			con.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	
	public static String palsgetPostgresDBQueryValue(String sqlQuery) {
		Connection con;
		String responseFetchedValue = null;
		try {
			con = connectToDB(dbconnection.getString(env + "PalsHost"), dbconnection.getString(env + "PalsPort"),
					dbconnection.getString(env + "PalsDatabase"), dbconnection.getString(env + "PalsUsername"),
					dbconnection.getString(env + "PalsPassword"));
			Statement stm = con.createStatement();
//		test.log(Status.DEBUG, "Query to fetch is" + sqlQuery);
			ResultSet rs = stm.executeQuery(sqlQuery);
			while (rs.next()) {
				responseFetchedValue = rs.getString(1);
			}
			rs.close();
			stm.close();
			con.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return responseFetchedValue;
	}
}
