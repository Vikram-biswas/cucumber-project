package utility;

import java.io.File;

import stepDefinitions.StepDefinition;

public class APIConstants {
	public static final String USER_DIR = System.getProperty("user.dir");

	public static final String CONFIG_FILE_PATH = USER_DIR + File.separator + "src" + File.separator + "test"
			+ File.separator + "resources" + File.separator + "config.properties";

	public static final String TESTDATA_FILE_PATH = USER_DIR + File.separator + "src" + File.separator + "test"
			+ File.separator + "resources" + File.separator + StepDefinition.env + "TestData.properties";

	public static final String APPLICATION_FILE_PATH = USER_DIR + File.separator + "src" + File.separator + "test"
			+ File.separator + "resources" + File.separator + "application.properties";

	public static final String DBCONNECTION_FILE_PATH = USER_DIR + File.separator + "src" + File.separator + "test"
			+ File.separator + "resources" + File.separator + "dbconnections.properties";

	public static final String TESTDATA_FOLDERPATH = USER_DIR + File.separator + "src" + File.separator + "test"
			+ File.separator + "java" + File.separator + "com" + File.separator + "testdata";

	public static final String ppBankAccountReports = USER_DIR + File.separator + "payloads" + File.separator
			+ "ppBankAccountReports.json";

}
