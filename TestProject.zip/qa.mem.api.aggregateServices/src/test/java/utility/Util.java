package utility;

import static io.restassured.RestAssured.given;

import static org.testng.Assert.assertEquals;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang.RandomStringUtils;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.aventstack.extentreports.Status;
import com.fasterxml.jackson.databind.JsonNode;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import runnerClass.TestRunner;

public class Util extends TestRunner {

  public static String getProperty(String key) {
		String keyName = null;
		try {
			keyName = testdata.getString(key);
			if (keyName != null || !keyName.isEmpty() || keyName != "") {
				test.log(Status.INFO, keyName);
			} else {
				keyName = application.getString(key);
			}
		} catch (Exception e) {
			test.log(Status.INFO, e);
		}
		return keyName;
	}

	/*
	 * This method is used to call POST request
	 */
	public static Response post(String url, JsonNode payload) throws Exception {
		Response response = given().headers(headers).contentType(ContentType.JSON).body(payload).post(url).andReturn();
		return response;
	}

	public static Response post(String url, String pathParam, String pathParamValue, JsonNode payload)
			throws Exception {
		Response response = given().headers(headers).contentType(ContentType.JSON).body(payload)
				.pathParam(pathParam, pathParamValue).post(url).andReturn();
		return response;
	}

	public static Response post(String url, String pathParam1, String pathParamValue1, String pathParam2,
			String pathParamValue2, String payload) throws Exception {
		Response response = given().headers(headers).contentType(ContentType.JSON).body(payload)
				.pathParam(pathParam1, pathParamValue1).pathParam(pathParam2, pathParamValue2).post(url).andReturn();
		return response;
	}
	
	public static Response post(String url, String pathParam1, String pathParamValue1, String pathParam2,
			String pathParamValue2, String pathParam3, String pathParamValue3, JsonNode payload) throws Exception {
		Response response = given().urlEncodingEnabled(false).headers(headers).contentType(ContentType.JSON).body(payload)
				.pathParam(pathParam1, pathParamValue1).pathParam(pathParam2, pathParamValue2).pathParam(pathParam3, pathParamValue3).post(url).andReturn();
		return response;
	}

	public static Response post(String url, String pathParam1, String pathParamValue1, String queryParam,
			String queryParamValue, String queryParam1, boolean queryParamValue1, String queryParam2,
			boolean queryParamValue2, String queryParam3, boolean queryParamValue3, JsonNode payload) throws Exception {
		Response response = given().headers(headers).contentType(ContentType.JSON).body(payload)
				.pathParam(pathParam1, pathParamValue1).queryParam(queryParam, queryParamValue)
				.queryParam(queryParam1, queryParamValue1).queryParam(queryParam2, queryParamValue2)
				.queryParam(queryParam3, queryParamValue3).post(url).andReturn();
		return response;
	}

	public static Response post(String url, String pathParam1, String pathParamValue1, String pathParam2,
			String pathParamValue2, String pathParam3, String pathParamValue3, String pathParam4,
			String pathParamValue4, JsonNode payload) throws Exception {
		Response response = given().headers(headers).contentType(ContentType.JSON).body(payload)
				.pathParam(pathParam1, pathParamValue1).pathParam(pathParam2, pathParamValue2)
				.pathParam(pathParam3, pathParamValue3).pathParam(pathParam4, pathParamValue4).post(url).andReturn();
		return response;
	}

	public static Response post(String url, String pathParam1, String pathParamValue1, String pathParam2,
			String pathParamValue2, String queryParam, String queryParamValue, String queryParam1,
			boolean queryParamValue1, String queryParam2, boolean queryParamValue2, String queryParam3,
			boolean queryParamValue3, String queryParam4, boolean queryParamValue4) throws Exception {
		Response response = given().headers(headers).contentType(ContentType.JSON)
				.pathParam(pathParam1, pathParamValue1).pathParam(pathParam2, pathParamValue2)
				.queryParam(queryParam, queryParamValue).queryParam(queryParam1, queryParamValue1)
				.queryParam(queryParam2, queryParamValue2).queryParam(queryParam3, queryParamValue3)
				.queryParam(queryParam4, queryParamValue4).post(url).andReturn();
		return response;
	}

	/*
	 * This method is used to call GET request
	 */
	public static Response get(String url, String pathParam, String pathParamValue) throws Exception {
		Response response = given().headers(headers).contentType(ContentType.JSON).pathParam(pathParam, pathParamValue)
				.get(url).andReturn();
		return response;
	}

	/*
	 * This method is used to call GET request including query param
	 */
	public static Response get(String url, String pathParam, String pathParamValue, String queryParam,
			boolean queryParamValue) throws Exception {
		Response response = given().headers(headers).contentType(ContentType.JSON).pathParam(pathParam, pathParamValue)
				.queryParam(queryParam, queryParamValue).get(url).andReturn();
		return response;
	}

	public static Response get1(String url, String pathParam, String pathParamValue, String queryParam,
			boolean queryParamValue) throws Exception {
		Response response = given().headers("Authorization", "Bearer o8ulj", "CompanyUUID", "ajkdlf9879")
				.contentType(ContentType.JSON).pathParam(pathParam, pathParamValue)
				.queryParam(queryParam, queryParamValue).get(url).andReturn();
		return response;
	}

	public static Response get(String url) throws Exception {

		Response response = given().headers(headers).contentType(ContentType.JSON).get(url).andReturn();
		return response;
	}

	public static Response get(String url, String pathParam1, String pathParamValue1, String pathParam2,
			String pathParamValue2, String queryParam, boolean queryParamValue) throws Exception {
		Response response = given().headers(headers).contentType(ContentType.JSON)
				.pathParam(pathParam1, pathParamValue1).pathParam(pathParam2, pathParamValue2)
				.queryParam(queryParam, queryParamValue).get(url).andReturn();
		return response;
	}

	public static Response get(String url, String pathParam1, String pathParamValue1, String pathParam2,
			String pathParamValue2) throws Exception {
		Response response = given().headers(headers).contentType(ContentType.JSON)
				.pathParam(pathParam1, pathParamValue1).pathParam(pathParam2, pathParamValue2).get(url).andReturn();
		return response;
	}

	public static Response get(String url, String pathParam1, String pathParamValue1, String pathParam2,
			String pathParamValue2, String pathParam3, String pathParamValue3) throws Exception {
		Response response = given().headers(headers).contentType(ContentType.JSON)
				.pathParam(pathParam1, pathParamValue1).pathParam(pathParam2, pathParamValue2)
				.pathParam(pathParam3, pathParamValue3).get(url).andReturn();
		return response;
	}

	public static Response get(String url, String pathParam1, String pathParamValue1, String pathParam2,
			String pathParamValue2, String pathParam3, String pathParamValue3, String pathParam4,
			String pathParamValue4) throws Exception {
		Response response = given().headers(headers).contentType(ContentType.JSON)
				.pathParam(pathParam1, pathParamValue1).pathParam(pathParam2, pathParamValue2)
				.pathParam(pathParam3, pathParamValue3).pathParam(pathParam4, pathParamValue4).get(url).andReturn();
		return response;
	}

	/*
	 * This method is used to call PUT request
	 */
	public static Response put(String url, JsonNode payload, String pathParam, String pathParamValue) throws Exception {
		Response response = given().headers(headers).contentType(ContentType.JSON).body(payload)
				.pathParam(pathParam, pathParamValue).put(url).andReturn();
		return response;
	}

	public static Response put(String url, JsonNode payload, String pathParam1, String pathParamValue1,
			String pathParam2, String pathParamValue2) throws Exception {
		Response response = given().headers(headers).contentType(ContentType.JSON).body(payload)
				.pathParam(pathParam1, pathParamValue1).pathParam(pathParam2, pathParamValue2).put(url).andReturn();
		return response;
	}

	public static Response put(String url, JSONArray payload) throws Exception {
		Response response = given().headers(headers).contentType(ContentType.JSON).body(payload).put(url).andReturn();
		return response;
	}

	/*
	 * This method is used to call DELETE request
	 */
	public static Response delete(String url, String pathParam, String pathParamValue) throws Exception {
		Response response = given().headers(headers).contentType(ContentType.JSON).pathParam(pathParam, pathParamValue)
				.delete(url).andReturn();
		return response;
	}

	public static Response delete(String url, String pathParam1, String pathParamValue1, String pathParam2,
			String pathParamValue2) {
		Response response = given().headers(headers).contentType(ContentType.JSON)
				.pathParam(pathParam1, pathParamValue1).pathParam(pathParam2, pathParamValue2).delete(url).andReturn();
		return response;
	}

	/*
	 * This is the utility method which returns JsonNode from string representation
	 * of JSON
	 */
	public static JsonNode getJsonNodeFromString(String json) throws ParseException {
		return (JsonNode) new JSONParser().parse(json);
	}

	/*
	 * This is the utility method which returns json file path
	 */
	public static JsonNode getJsonNodeFromFilePath(String filePath)
			throws FileNotFoundException, IOException, ParseException {
		return (JsonNode) new JSONParser().parse(new FileReader(filePath));
	}

	/*
	 * This is the utility method which returns JSONArray from string
	 */
	public static JSONArray getJSONArrayFromString(String json) throws ParseException {
		return (JSONArray) new JSONParser().parse(json);

	}

	/*
	 * This is the utility method which returns first Json object from JSONArray
	 */
	public static JsonNode getFirstJsonNode(JSONArray jsonArray) {
		return (JsonNode) jsonArray.stream().findFirst().get();

	}

	/*
	 * This is the utility method which returns access token
	 */
	@SuppressWarnings("unchecked")
	public static String getAccessToken() throws Exception {
		@SuppressWarnings("rawtypes")
		Map<String, String> header = new HashMap();
		header.put("Authorization", config.getString("authCode"));
		String token = "Bearer ";
		Response response = given().headers(header).contentType(ContentType.JSON).contentType(ContentType.URLENC)
				.formParam("grant_type", "client_credentials").post(config.getString("oauthURL")).andReturn();
		JsonNode jsonResponse = mapper.readTree(response.getBody().asString());
		String access_token = jsonResponse.get("access_token").asText();
		return token + access_token;

	}

	/*
	 * This is the utility method to connect to postgress db
	 * 
	 */
	public static Connection connectToDB(String host, String port, String db, String userName, String pswd)
			throws SQLException, ClassNotFoundException {
		Connection connection = DriverManager.getConnection("jdbc:postgresql://" + host + ":" + port + "/" + db,
				userName, pswd);
		Class.forName("org.postgresql.Driver");
		return connection;
	}

	public static Connection connectToSQLServer(String serverName, String port, String dbName, String userName,
			String pswd) throws Exception {

		String connectionUrl = "jdbc:sqlserver://" + serverName + ":" + port + ";" + "databaseName=" + dbName + ";user="
				+ userName + ";password=" + pswd;
		Connection connection = DriverManager.getConnection(connectionUrl);
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		return connection;
	}

	/*
	 * This is utility method which returns 4 digit random number
	 */
	public static long randomNumber() {

		return Math.round(Math.random() * 10000);

	}

	public static String randomAlphanumberic() {
		return RandomStringUtils.randomAlphanumeric(4).toUpperCase();
	}

	/*
	 * This is the utility method which returns json based on parameter
	 */
	public static JsonNode getPayloadFromJson(JsonNode payload, String payloadType) {

		return (JsonNode) payload.get(payloadType);

	}

	/*
	 * This is the utility method which is used to assert response status code and
	 * return json response
	 */

	public static JsonNode assertStatusCode(Response response, StatusCode statusCode) throws Exception {
		test.log(Status.INFO, "Assert response status code as " + statusCode.getMessage());
		test.log(Status.INFO, "Actual Response Status Code = " + response.getStatusLine());
		test.log(Status.INFO, "Expected status code = " + statusCode.getMessage());
		test.log(Status.DEBUG, "============Response Body===========");
		test.log(Status.DEBUG, response.getBody().asString());
		assertEquals(response.getStatusLine(), statusCode.getMessage(), "Status code validation failed");
		JsonNode jsonResponse = mapper.readTree(response.getBody().asString());
		return jsonResponse;
	}

	public static String randomUuid() {
		return UUID.randomUUID().toString();
	}

	public static String licenseCreation() throws Exception {
		String studioId = null, divisionId = null;
		String insertStudioQuery = "insert into pals.studio (studio_name,vcg_id,db_security_group_id) values ('stName',16,1)";
		String insertDivisionQuery = "insert into pals.division (studio_id, division_name) values (?,'DivName')";
		String insertLicenseQuery = "insert into pals.license (division_id,product_type_id,system_type_id,license_key,product_name,db_name,uri,region_id,install_url,software_version,deployment_type_id,sql_server_instance_id) values (?,1,4,'RE94','Regg_AppleStudiosLLC_35','EaseAccounting_Regg_AppleStudiosLLC_35','http://csqeact01.ep.corp/EaseAccounting_Regg_AppleStudiosLLC_35/',14,'http://csqeact01.ep.corp/EaseAccounting_Regg_AppleStudiosLLC_35/install/EaseInstall.exe','1.9.35.00592',1,1)";

		String ran = Util.randomAlphanumberic();

		if (!DbUtil.ifRecordExistpals(dbconnection.getString("ifLicenseExist"))) {
			DbUtil.palsinsertDeleteRecord(insertStudioQuery.replace("stName", "AutoSt" + ran));
			studioId = DbUtil
					.palsgetPostgresDBQueryValue(dbconnection.getString("getStudioId").replace("?", "AutoSt" + ran));
			String query = insertDivisionQuery.replace("?", studioId);
			DbUtil.palsinsertDeleteRecord(query.replace("DivName", "AutoDiv" + ran));
			divisionId = DbUtil.palsgetPostgresDBQueryValue(
					dbconnection.getString("getDivisionQuery").replace("?", "AutoDiv" + ran));
			DbUtil.palsinsertDeleteRecord(insertLicenseQuery.replace("?", divisionId));

		}

		return "RE94";

	}
	
	public static Response getByPathAndQueryParam(String url, String pathParam, String pathParamValue,
			String queryParam, String queryParamValue) throws Exception {

		Response response = given().headers(headers).contentType(ContentType.JSON).pathParam(pathParam, pathParamValue)
				.queryParam(queryParam, queryParamValue).get(url).andReturn();
		return response;
	}
	
	public static Response getQueryParam(String url, 
			String queryParam, String queryParamValue) throws Exception {

		Response response = given().headers(headers).contentType(ContentType.JSON)
				.queryParam(queryParam, queryParamValue).get(url).andReturn();
		return response;
	}
}
