package utility;

public enum StatusCode {
	STATUS_200(200), STATUS_201(201), STATUS_202(202), STATUS_204(204), STATUS_500(500), STATUS_400(400),
	STATUS_401(401), STATUS_404(404), MESSAGE_201("HTTP/1.1 201 Created"), MESSAGE_200("HTTP/1.1 200 OK"),
	MESSAGE_204("HTTP/1.1 204 No Content"), MESSAGE_400("HTTP/1.1 400 Bad Request"),
	MESSAGE_401("HTTP/1.1 401 Unauthorized"), MESSAGE_403("HTTP/1.1 403 Forbidden"),
	MESSAGE_409("HTTP/1.1 409 Conflict"), MESSAGE_404("HTTP/1.1 404 Not Found"),
	MESSAGE_406("HTTP/1.1 406 Not Acceptable"), MESSAGE_202("HTTP/1.1 202 Accepted"),
	MESSAGE_500("HTTP/1.1 500 Internal Server Error");
	int value;
	String message;
	
	private StatusCode(int value) {
		this.value = value;
	}
	
	private StatusCode(String message) {
		this.message = message;
	}

	public int getValue() {
		return this.value;
	}

	public String getMessage() {
		return this.message;
	}
}
