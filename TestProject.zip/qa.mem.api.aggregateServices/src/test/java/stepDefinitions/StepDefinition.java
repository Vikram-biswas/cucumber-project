package stepDefinitions;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.commons.configuration.ConfigurationException;

import com.aventstack.extentreports.Status;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import runnerClass.TestRunner;
import utility.AggregateServiceHelper;
import utility.DbUtil;
import utility.StatusCode;
import utility.Util;

public class StepDefinition extends TestRunner {
	public static String name = null;
	public static String url = null;
	public static String payloadPath = null;
	public static JsonNode Payload;
	public static JsonNode Response;
	public static Response response;
	boolean flag = true;
	String responseCount;

	@Before
	public void before(Scenario scenario) {
		test = extent.createTest(scenario.getName());
	}

	@Given("the post uri {string} is configured")
	public void the_post_uri_is_configured(String endpnt) throws Exception {
		try {
			payloadPath = endpnt;
			test.log(Status.DEBUG, "Read target url from config file");
			url = AggregateServiceHelper.buildURI(config.getString(endpnt));

			test.log(Status.DEBUG, "URL=" + url);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Given("the put uri {string} is configured")
	public void the_put_uri_is_configured(String endpnt) throws Exception {
		try {
			payloadPath = endpnt;
			test.log(Status.DEBUG, "Read target url from config file");
			url = AggregateServiceHelper.buildURI(config.getString(endpnt));

			test.log(Status.DEBUG, "URL=" + url);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Given("the GET uri {string} is configured")
	public void the_get_uri_is_configured(String endPoint) {
		test.log(Status.DEBUG, "Read target url from config file");
		url = AggregateServiceHelper.buildURI(config.getString(endPoint));
		test.log(Status.INFO, "Target URL = " + url);
	}

	@Given("the GET swagger uri {string} is configured")
	public void the_get_swagger_uri_is_configured(String endPoint) {
		test.log(Status.DEBUG, "Read target url from config file");
		url = AggregateServiceHelper.buildURISwagger(config.getString(endPoint));
		test.log(Status.INFO, "Target URL = " + url);
	}

	@Given("the delete uri {string} is configured")
	public void the_delete_uri_with_is_configured(String endPoint) {
		url = AggregateServiceHelper.buildURI(config.getString(endPoint));
		test.log(Status.DEBUG, "Target URL = " + url);
	}

	@When("the post call is made")
	public void the_post_call() throws Exception {
		Response = AggregateServiceHelper.createNewRecord(Payload, StatusCode.MESSAGE_201);
		test.log(Status.DEBUG, Response.toString());
	}

	@Given("the payload is built for test")
	public void the_payload_is_built_for_test_positive_test(DataTable dataTable) throws Exception {
		List<String> fields = dataTable.asList();
		Payload = AggregateServiceHelper.setPayload();
		test.log(Status.INFO, "Veriying to fetch positive pay bank account reports with valid payload");
		for (String val : fields) {
			String value = null;
			if (val.equals("account_number")) {
				((ObjectNode) Payload).put("account_number", DbUtil.getSQLQueryValue(
						dbconnection.getString("SQLBankAccountNumber").replace("?", Util.getProperty("bankName"))));
			} else if (val.equals("organization_uuid")) {
				((ObjectNode) Payload).put("organization_uuid", DbUtil.getPostgresDBQueryValue(
						dbconnection.getString("PGOrganisationUuid").replace("?", Util.getProperty("licenseKey"))));
			}
		}
		test.log(Status.INFO, "================== ppBankAccount reports payload====================");
		test.log(Status.INFO, Payload.toString());
	}

	@Then("validate response with field {string} and value {string}")
	public void validate_get_response(String field, String value) throws Throwable {
		test.log(Status.DEBUG, "================Validating field in get Response body===================");
		AggregateServiceHelper.validatefieldResponse(Response, field,
				DbUtil.getSQLQueryValue(dbconnection.getString(value)));
	}

	@Then("validate count from serviceDB {string}")
	public void validate_count_from_serviceDB(String count) throws ClassNotFoundException, SQLException {
		String regionCount = DbUtil.getPostgresDBQueryValue(dbconnection.getString(count));
		test.log(Status.DEBUG, "Validating " + count);
		test.log(Status.DEBUG, count + " from API = " + responseCount);
		test.log(Status.DEBUG, count + " from DB = " + regionCount);
		assertEquals(responseCount, regionCount, count + " Validation is Failed");
	}

	@Then("validate the response with field {string} and value {string}")
	public void validate_field_response(String field, String value) throws Throwable {
		test.log(Status.DEBUG, "================Validating field in get Response body===================");
		AggregateServiceHelper.validateGetResponse(Response, field, value);
	}

	@When("the companies get call with pathParam {string} is made")
	public void the_companies_get_call_is_made(String pathParam) throws Exception {
		if (pathParam.equalsIgnoreCase("null")) {
			responseCount = AggregateServiceHelper.getrecords();
		}
	}

	@When("the get call with pathParam {string} is made")
	public void the_get_call_is_made(String pathParam) throws Exception {
		if (pathParam.equalsIgnoreCase("null")) {
			responseCount = AggregateServiceHelper.getrecords();
		}
	}

	@When("the get call with queryParam for valid data")
	public Response the_get_call_is_made_queryParam_for_valid_data(DataTable data) throws Exception {
		Map<String, String> fields = data.asMap(String.class, String.class);
		for (Map.Entry<String, String> val : fields.entrySet()) {
			if (val.getKey().equalsIgnoreCase("$filter")) {
				String value = val.getValue();
				String[] filterValue = value.split(" eq ");
				String filterQuery = value.replace(filterValue[1], '\'' + Util.getProperty(filterValue[1]) + '\'');
				response = Util.getQueryParam(StepDefinition.url, val.getKey(), filterQuery);
				JsonNode jsonResponse = Util.assertStatusCode(response, StatusCode.MESSAGE_200);
				test.log(Status.INFO, "Verifying $filter query param");
				int noOfObjects = 1;
				test.log(Status.INFO, "Expected fields count in response = " + noOfObjects);
				test.log(Status.INFO, "Actual fields count in response = " + jsonResponse.get("items").size());
				assertEquals(jsonResponse.get("items").size(), noOfObjects);
			} else if (val.getKey().equalsIgnoreCase("$orderby")) {
				response = Util.getQueryParam(StepDefinition.url, val.getKey(), val.getValue().replace("?", ""));
				JsonNode jsonResponse = Util.assertStatusCode(response, StatusCode.MESSAGE_200);
				test.log(Status.INFO, "Verifying $orderby query param with ASC ");
				String actualResult = jsonResponse.get("items").get(0).get(val.getValue()).asText();
				String expectedResult = DbUtil.getPostgresDBQueryValue(dbconnection.getString(val.getValue()));
				test.log(Status.INFO, "Expected field name in response = " + expectedResult);
				test.log(Status.INFO, "Actual field name in response = " + actualResult);
				assertEquals(actualResult, expectedResult);
			} else if (val.getKey().equalsIgnoreCase("$top")) {
				response = Util.getQueryParam(StepDefinition.url, val.getKey(), val.getValue().replace("?", ""));
				JsonNode jsonResponse = Util.assertStatusCode(response, StatusCode.MESSAGE_200);
				test.log(Status.INFO, "Verifying $top query param");
				String top = val.getValue();
				test.log(Status.INFO, "Expected top count in response = " + top);
				test.log(Status.INFO, "Actual top count in response = " + jsonResponse.get("items").size());
				assertEquals(jsonResponse.get("items").size(), Integer.parseInt(top));
			} else if (val.getKey().equalsIgnoreCase("$skip")) {
				response = Util.getQueryParam(StepDefinition.url, val.getKey(), val.getValue());
				JsonNode jsonResponse = Util.assertStatusCode(response, StatusCode.MESSAGE_200);
				test.log(Status.INFO, "Verifying $skip query param");
				int skip = Integer.parseInt(val.getValue());
				String total = jsonResponse.get("total_count").toString();
				int result = Integer.parseInt(total) - (Integer.parseInt(total) - skip);
				test.log(Status.INFO, "Expected skip count in response = " + skip);
				test.log(Status.INFO, "Actual skip count in response = " + result);
				assertEquals(result, skip);
			} else if (val.getKey().equalsIgnoreCase("columns")) {
				response = Util.getQueryParam(StepDefinition.url, val.getKey(), val.getValue().replace("?", ""));
				JsonNode jsonResponse = Util.assertStatusCode(response, StatusCode.MESSAGE_200);
				test.log(Status.INFO, "Verifying columns query param");
				assertEquals(1, (jsonResponse.get("items").get(0).size()));
				test.log(Status.INFO, "Expected column name in response = " + val.getValue());
				test.log(Status.INFO, "Actual column name in response = "
						+ jsonResponse.get("items").get(0).fieldNames().next().toString());
				assertEquals(jsonResponse.get("items").get(0).fieldNames().next().toString(), val.getValue());

			}
		}
		return response;

	}

	@When("the get call with queryParam for Invalid data")
	public Response the_get_call_is_made_queryParam_invalid_data(DataTable data) throws Exception {

		Map<String, String> fields = data.asMap(String.class, String.class);
		for (Map.Entry<String, String> val : fields.entrySet()) {
			response = Util.getQueryParam(StepDefinition.url, val.getKey(), val.getValue());
		}
		return response;
	}

	@Then("the get call is made to validate error code {string}")
	public void the_get_call_is_made_withErrorCode(String errorCode) throws Exception {
		if (errorCode.contains("406")) {
			Util.assertStatusCode(response, StatusCode.MESSAGE_406);
		} else if (errorCode.contains("204")) {
			Util.assertStatusCode(response, StatusCode.MESSAGE_204);
		} else if (errorCode.contains("401")) {
			Util.assertStatusCode(response, StatusCode.MESSAGE_401);
		} else if (errorCode.contains("404")) {
			Util.assertStatusCode(response, StatusCode.MESSAGE_404);
		} else if (errorCode.contains("409")) {
			Util.assertStatusCode(response, StatusCode.MESSAGE_409);
		} else if (errorCode.contains("500")) {
			Util.assertStatusCode(response, StatusCode.MESSAGE_500);
		} else if (errorCode.contains("400")) {
			Util.assertStatusCode(response, StatusCode.MESSAGE_400);
		}
	}

	@When("the get call with invalid url")
	public Response the_get_call_is_made_with_invalid_url() throws Exception {
		response = AggregateServiceHelper.getResponseInvalidURLForNegative();
		return response;
	}

	@When("the get call with pathParam {string} and value {string} and wihtout Authorization")
	public Response the_get_call_is_made_without_authorization(String pathParam, String pathParamValue)
			throws Exception {
		if (pathParam.equalsIgnoreCase("null")) {
			headers.put("Authorization", "17831cca-e28c-4aa4-b782-9be9daf8afc5");
			response = AggregateServiceHelper.getAllResponse();
		} else if (pathParam.equalsIgnoreCase(pathParam)) {
			headers.put("Authorization", "Bearer ");
			response = AggregateServiceHelper.getResponseForNegative(pathParam, Util.getProperty(pathParamValue));
		}

		return response;
	}

	@Then("get projectbatchexternalid from service DB")
	public void store_the_ProjectBatchexternalid() throws ConfigurationException {
		String query = null;
		query = dbconnection.getString("getProjectBatchesbyexternalid");
		String ProjectBatchexternalid = DbUtil.getPostgresDBQueryValue(query);
		System.out.println(ProjectBatchexternalid);
		testdata.setProperty("ProjectBatchexternalid", ProjectBatchexternalid);
		testdata.save();
	}

	@When("the get call with pathParam {string} and value {string} and statusCode {string} is made")
	public void the_projectBatches_get_call_is_made(String pathParam, String pathParamValue, String statuCode)
			throws Exception {
		if (statuCode.contains("400")) {
			test.log(Status.DEBUG, "Fetched Parameter Value = " + Util.getProperty(pathParamValue));
			Response response = Util.get(StepDefinition.url, pathParam, Util.getProperty(pathParamValue));
			Util.assertStatusCode(response, StatusCode.MESSAGE_400);
		} else if (statuCode.contains("403")) {
			test.log(Status.DEBUG, "Fetched Parameter Value = " + Util.getProperty(pathParamValue));
			Response response = Util.get(StepDefinition.url, pathParam, Util.getProperty(pathParamValue));
			Util.assertStatusCode(response, StatusCode.MESSAGE_403);
		} else if (statuCode.contains("200")) {
			test.log(Status.DEBUG, "Fetched Parameter Value = " + Util.getProperty(pathParamValue));
			Response response = Util.get(StepDefinition.url, pathParam, Util.getProperty(pathParamValue));
			Util.assertStatusCode(response, StatusCode.MESSAGE_200);
		} else if (statuCode.contains("204")) {
			test.log(Status.DEBUG, "Fetched Parameter Value = " + Util.getProperty(pathParamValue));
			Response response = Util.get(StepDefinition.url, pathParam, Util.getProperty(pathParamValue));
			Util.assertStatusCode(response, StatusCode.MESSAGE_204);
		} else if (statuCode.contains("404")) {
			test.log(Status.DEBUG, "Fetched Parameter Value = " + Util.getProperty(pathParamValue));
			Response response = Util.get(StepDefinition.url, pathParam, Util.getProperty(pathParamValue));
			Util.assertStatusCode(response, StatusCode.MESSAGE_404);
		} else if (statuCode.contains("401")) {
			test.log(Status.DEBUG, "Fetched Parameter Value = " + Util.getProperty(pathParamValue));
			Response response = Util.get(StepDefinition.url, pathParam, Util.getProperty(pathParamValue));
			Util.assertStatusCode(response, StatusCode.MESSAGE_401);
		}

	}

	@Then("get call with getGlTransactionAttachmentsbyexternalid service DB")
	public void store_the_GlTransactionAttachmentsbyexternalid() throws ConfigurationException {
		String query = null;
		query = dbconnection.getString("getGlTransactionAttachmentsbyexternalid");
		String GlTransactionAttachmentexternalid = DbUtil.getPostgresDBQueryValue(query);
		System.out.println(GlTransactionAttachmentexternalid);
		testdata.setProperty("GlTransactionAttachmentexternalid", GlTransactionAttachmentexternalid);
		testdata.save();
	}

	@Then("get GlTransactionApprovalbyexternalid from service DB")
	public void store_the_GlTransactionApprovalsbyexternalid() throws ConfigurationException {
		String query = null;
		query = dbconnection.getString("getGlTransactionApprovalexternalid");
		String GlTransactionApprovalexternalid = DbUtil.getPostgresDBQueryValue(query);
		System.out.println(GlTransactionApprovalexternalid);
		testdata.setProperty("GlTransactionApprovalexternalid", GlTransactionApprovalexternalid);
		testdata.save();
	}

	@Then("get call with getGlTransactionApprovalbyApprovalStatus service DB")
	public void store_the_GlTransactionApprovalbyApprovalStatus() throws ConfigurationException {
		String query = null;
		query = dbconnection.getString("getGlTransactionApprovalbyApprovalStatus");
		String GlTransactionApprovalbyApprovalStatus = DbUtil.getPostgresDBQueryValue(query);
		testdata.setProperty("GlTransactionApprovalbyApprovalStatus", GlTransactionApprovalbyApprovalStatus);
		testdata.save();
	}

	@Then("get ProjectGlTransactionbyexternalid from service DB")
	public void store_the_ProjectGlTransactionbyexternalId() throws ConfigurationException {
		String query = null;
		query = dbconnection.getString("getProjectGlTransactionbyexternalId");
		String ProjectGlTransactionbyexternalId = DbUtil.getPostgresDBQueryValue(query);
		testdata.setProperty("ProjectGlTransactionbyexternalId", ProjectGlTransactionbyexternalId);
		testdata.save();
	}

	@Then("get ProjectGlTransactionbyProjectPeriodId service DB")
	public void store_the_ProjectGlTransactionbyProjectPeriodId() throws ConfigurationException {
		String query = null;
		query = dbconnection.getString("getProjectGlTransactionbyProjectPeriodId");
		String ProjectGlTransactionbyProjectPeriodId = DbUtil.getPostgresDBQueryValue(query);
		testdata.setProperty("ProjectGlTransactionbyProjectPeriodId", ProjectGlTransactionbyProjectPeriodId);
		testdata.save();
	}

	@Then("get ProjectGlTransactionbyProjectBatchId service DB")
	public void store_the_ProjectGlTransactionbyProjectBatchId() throws ConfigurationException {
		String query = null;
		query = dbconnection.getString("getProjectGlTransactionbyProjectBatchId");
		String ProjectGlTransactionbyProjectBatchId = DbUtil.getPostgresDBQueryValue(query);
		testdata.setProperty("ProjectGlTransactionbyProjectBatchId", ProjectGlTransactionbyProjectBatchId);
		testdata.save();
	}

	@Then("get {string} from service DB")
	public void store_the_details(String key) throws ConfigurationException {
		String query = null;
		query = dbconnection.getString(key);
		String batchexternalid = DbUtil.getPostgresDBQueryValue(query);
		testdata.setProperty(key, batchexternalid);
		testdata.save();
	}

	@When("the get call with params {string} and {string} is made")
	public void the_get_call_is_made(String pathParam, String paramValue) throws Exception {
		if (pathParam.equalsIgnoreCase("null")) {
			responseCount = AggregateServiceHelper.getrecords();
		} else {
			Response = AggregateServiceHelper.getResponseParam(pathParam, Util.getProperty(paramValue));
		}
	}

	@Then("store paymentInfoExternal details")
	public void store_the_paymentInfoExternal() throws ConfigurationException {
		String paymentInfoExternalid = Response.get("items").get(0).get("external_id").asText();
		testdata.setProperty("paymentInfoExternalid", paymentInfoExternalid);
		testdata.save();
	}

	@Then("validate record count from serviceDB {string} and api record {string}")
	public void validate_record_count_from_serviceDB(String dbcount, String apicount)
			throws ClassNotFoundException, SQLException {
		String regionCount = DbUtil.getPostgresDBQueryValue(
				dbconnection.getString(dbcount).replace("fieldValue", Util.getProperty(apicount)));
		test.log(Status.DEBUG, "Validating " + dbcount);
		test.log(Status.DEBUG, dbcount + " from API = " + Response.size());
		test.log(Status.DEBUG, dbcount + " from DB = " + regionCount);
		assertEquals(String.valueOf(Response.size()), regionCount, dbcount + " Validation is Failed");
	}

}
